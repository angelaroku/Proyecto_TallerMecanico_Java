package proyecto_taller.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import proyecto_taller.dao.DAO_TallerMecanico;
import proyecto_taller.vista.ModificacionVehiculosVista;

public class ModificarVehiculosControlador implements ActionListener {
	
	private ModificacionVehiculosVista vistaControlador;
	private DAO_TallerMecanico daoControlador;


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
