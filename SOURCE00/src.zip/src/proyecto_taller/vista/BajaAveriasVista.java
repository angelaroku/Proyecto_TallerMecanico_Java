package proyecto_taller.vista;

import javax.swing.JPanel;

public class BajaAveriasVista extends JPanel{

	private static final long serialVersionUID = 1L;

	public BajaAveriasVista() {
		setLayout(null);
	}

}
