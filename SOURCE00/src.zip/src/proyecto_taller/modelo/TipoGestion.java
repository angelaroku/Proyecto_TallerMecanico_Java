package proyecto_taller.modelo;

public enum TipoGestion {
	RECEPCION_VEHICULO, TERMINACION_REPARACION, ENTREGA_VEHICULOS_REPARADOS;
}
