package proyecto_taller.modelo;

public enum EstadoVehiculo {
	EN_REPARACION, EN_ESPERA, REPARADO;

}
