package $notas;
/*
	--> mvc LISTO CON METODOS EN MODELO
		-Generar modelos
			Averia [+], Mecanico [ ], Vehiculo [ ] Taller [ ], 
			Fichero[ ], Gestion[ ]
		
		- Generar documentos vistas
			GENprincipal[+], Averia [+], Mecanico [+], Vehiculo [+]
			Fichero[+], Gestion[+]
			
		- generar documentos controladores(revisar)
			Averia [ +,falta actionPerform]
			Mecanico [+ ,falta actionPerform]
			Vehiculo [+,falta actionPerform]
			Fichero[ -- ,falta actionPerform]
			Gestion[ -- ,falta actionPerform]
		
		- CONECTAR vista - contolador
			Averia [ ], Mecanico [ ], Vehiculo [ ]
		
		- diseñar metodos crud del modelo  "Taller Mecanico"[ ]
		
		
	--> exportar importar ()
		- Vistas
			Averia [ ], Mecanico [ ], Vehiculo [ ]
		-Controladores
			Averia [ ], Mecanico [ ], Vehiculo [ ]
		- CONECTAR vista - contolador
			Averia [ ], Mecanico [ ], Vehiculo [ ]
			
	--> CRUD  y export e import funcional
		- metodos de elementos que recogen datos en vistas
			Averia [ ], Mecanico [ ], Vehiculo [ ], Exportar [ ], Importar [ ] 
			
		- Armar ActionPerformed en controladores
			Averia [ ], Mecanico [ ], Vehiculo [ ], Exportar [ ], Importar [ ] 
		
		
		
	--> BBDD SQL(JPA)- MavenProject - trabajo en DAO
		- agregar dependencias pom.xml[ ]
		- diseñar dao (llama solo a Modelo)JPA[ ]
			Recoger metodos del crud en "TallerMecanico" [ ]
	

* */