package $notas;
/*
	--> mvc LISTO CON METODOS EN MODELO
		-Generar modelos
			Averia [+], Mecanico [ ], Vehiculo [ ] Taller [ ], 
			Fichero[ ], Gestion[ ]
		
		- Generar documentos vistas
			GENprincipal[+], Averia [+], Mecanico [+], Vehiculo [+]
			Fichero[+], Gestion[+]
			
		- generar documentos controladores(revisar)
			Averia [ +,falta actionPerform]
			Mecanico [+ ,falta actionPerform]
			Vehiculo [+,falta actionPerform]
			Fichero[+,falta actionPerform]
			Gestion[+,falta actionPerform]
		
		- CONECTAR vista - contolador
			Averia [+], Mecanico [+], Vehiculo [+]
			Fichero[+], Gestion[+]
			
			
		- Taller Mecanico:
			- metodos CRUD del modelo  "Taller Mecanico"[+]
			- metodos IMPORTAR EXPORT fichero[]
			- metodos gestiones g1[] g2[] g3[]
		
	--> exportar importar metodos en Fichero
		- Exportar()[]
		- Importar()[]
			
	--> CRUD  y export e import funcional
		- metodos de elementos que recogen datos en vistas
			Averia [ ], Mecanico [ ], Vehiculo [ ], Exportar [ ], Importar [ ] 
			
		- Armar ActionPerformed en controladores
			Averia [ ], Mecanico [ ], Vehiculo [ ], Exportar [ ], Importar [ ] 
		
		
		
	--> BBDD SQL(JPA)- MavenProject - trabajo en DAO
		- agregar dependencias pom.xml[ ]
		- diseñar dao (llama solo a Modelo)JPA[ ]
			- Recoger metodos exportar e importar en "Fichero"[ ]
			- Recoger metodos de cada gestion
						-
						-
						-
			- Recoger metodos del crud en "TallerMecanico" [ ]
	

* */