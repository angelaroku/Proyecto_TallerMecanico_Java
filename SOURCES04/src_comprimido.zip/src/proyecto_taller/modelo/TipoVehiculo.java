package proyecto_taller.modelo;

public enum TipoVehiculo {
	COCHE, MOTO;
}
