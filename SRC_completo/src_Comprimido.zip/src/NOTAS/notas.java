package NOTAS;

public class notas {
 /*
 
  --> revisar YA ESTA TODUU JJUNTO(avances clase - casa)
  
  1- REVISAR MODELO
  			-CLASES ESPECIFICAS (COCHE/MOTO) 
  					heredan o como enum? RA7
  			-completar METODOS en MODELOS
 				--> Menu Taller Mecanico++, MECANICO, VEHICULO
 		
 2- boton  atras funcional a todas las vistas
 		¿Como uno dao con modelo con el menu gen?
 		¿Deberia hacer una nueva clase vista MenuTaller para notocar mi menu gen?
 	
 
 3- completar dao 
 		- METODOS CRUD
 		- ¿metodo para volver a inicio??
 
 
  
  * */
}
