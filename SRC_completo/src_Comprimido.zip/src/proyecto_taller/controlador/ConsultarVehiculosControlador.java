package proyecto_taller.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import proyecto_taller.dao.DAO_TallerMecanico;
import proyecto_taller.vista.ConsultaVehiculosVista;

public class ConsultarVehiculosControlador implements ActionListener{
	private ConsultaVehiculosVista vistaControlador;
	private DAO_TallerMecanico daoControlador;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
