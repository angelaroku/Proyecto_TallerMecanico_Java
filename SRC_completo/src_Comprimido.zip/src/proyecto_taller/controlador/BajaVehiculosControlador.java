package proyecto_taller.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import proyecto_taller.dao.DAO_TallerMecanico;
import proyecto_taller.vista.BajaVehiculosVista;

public class BajaVehiculosControlador implements ActionListener{
	
	private BajaVehiculosVista vistaControlador;
	private DAO_TallerMecanico daoControlador;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
