package proyecto_taller.modelo;

public enum EspecialidadMecanico {
	ESPECIALIDADMECANICO_COCHE, ESPECIALIDADMECANICO_MOTO;
}
