package proyecto_taller.modelo;

import java.util.ArrayList;

public class Moto extends Vehiculo{

	public Moto(String matricula, EstadoVehiculo estadoVehiculo, TipoVehiculo tipoVehiculo,
			ArrayList<Averia> averiasVehiculo) {
		super(matricula, estadoVehiculo, tipoVehiculo, averiasVehiculo);
		// TODO Auto-generated constructor stub
	}

}
