package proyecto_taller.modelo;

import java.util.ArrayList;

public class Coche extends Vehiculo{

	public Coche(String matricula, EstadoVehiculo estadoVehiculo, TipoVehiculo tipoVehiculo,
			ArrayList<Averia> averiasVehiculo) {
		super(matricula, estadoVehiculo, tipoVehiculo, averiasVehiculo);
		// TODO Auto-generated constructor stub
	}

}
