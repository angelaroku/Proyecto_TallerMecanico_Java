package proyecto_taller.vista;

import javax.swing.JPanel;

public class AltaAveriasVista extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public AltaAveriasVista() {
		setLayout(null);
	}

}
