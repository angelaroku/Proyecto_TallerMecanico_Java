package proyecto_taller.vista;

import javax.swing.JPanel;

public class GestionEntregaVehiculosReparadosVista extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public GestionEntregaVehiculosReparadosVista() {
		setLayout(null);

	}

}
