package proyecto_taller.vista;

import javax.swing.JPanel;

public class GestionRecepcionVehiculoVista extends JPanel {

	private static final long serialVersionUID = 1L;


	public GestionRecepcionVehiculoVista() {
		setLayout(null);

	}
}
