package proyecto_taller.vista;

import javax.swing.JPanel;

public class FicherosImportarVista extends JPanel{

	private static final long serialVersionUID = 1L;


	public FicherosImportarVista() {
		setLayout(null);

	}
	
}
