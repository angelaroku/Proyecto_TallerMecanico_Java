package proyecto_taller.vista;

import javax.swing.JPanel;

public class ModificacionAveriasVista extends JPanel{

	private static final long serialVersionUID = 1L;

	public ModificacionAveriasVista() {
		setLayout(null);
	}

}
