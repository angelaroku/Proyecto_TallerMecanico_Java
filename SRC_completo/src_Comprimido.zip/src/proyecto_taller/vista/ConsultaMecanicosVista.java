package proyecto_taller.vista;

import javax.swing.JPanel;

public class ConsultaMecanicosVista  extends JPanel {
	
	
	public ConsultaMecanicosVista() {
		setLayout(null);
	}

}
