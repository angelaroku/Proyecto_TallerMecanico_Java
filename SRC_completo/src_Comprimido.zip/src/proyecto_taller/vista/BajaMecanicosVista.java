package proyecto_taller.vista;

import javax.swing.JPanel;

public class BajaMecanicosVista  extends JPanel {
	public BajaMecanicosVista() {
		setLayout(null);
	}

}
