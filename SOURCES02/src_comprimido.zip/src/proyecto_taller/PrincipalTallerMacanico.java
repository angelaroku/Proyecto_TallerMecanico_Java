package proyecto_taller;


public class PrincipalTallerMacanico {
	public static void main(String[] args) {
		MenuGenTallerMecanico menu = new MenuGenTallerMecanico();
		menu.setSize(600, 600);
		menu.setVisible(true);
		
		
	}
}
