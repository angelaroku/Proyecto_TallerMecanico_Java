package proyecto_taller.vista;

import javax.swing.JPanel;

public class ModificacionMecanicosVista  extends JPanel {
	public ModificacionMecanicosVista() {
		setLayout(null);
	}

}
