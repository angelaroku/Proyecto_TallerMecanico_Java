package proyecto_taller.vista;

import javax.swing.JPanel;

public class ConsultaAveriasVista extends JPanel{

	private static final long serialVersionUID = 1L;

	public ConsultaAveriasVista() {
		setLayout(null);
	}

}
